import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send } from "lucide-react";
import { toast } from "sonner";
import { Header } from "@/components/common/Header";

const CycleReview = () => {
  const navigate = useNavigate();
  const [responses, setResponses] = useState({
    whatWorked: "",
    whatDidntWork: "",
    adjustments: "",
  });
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);

  const questions = [
    {
      key: "whatWorked",
      title: "O que deu certo esta semana?",
      subtitle: "Reflita sobre seus sucessos e conquistas",
      placeholder: "Ex: Consegui manter o foco nas tarefas prioritárias...",
    },
    {
      key: "whatDidntWork",
      title: "O que não deu certo?",
      subtitle: "Identifique os desafios e obstáculos",
      placeholder: "Ex: Tive dificuldade em gerenciar meu tempo...",
    },
    {
      key: "adjustments",
      title: "Quais ajustes você precisa fazer?",
      subtitle: "Planeje melhorias para a próxima semana",
      placeholder: "Ex: Vou bloquear horários específicos para tarefas importantes...",
    },
  ];

  const currentQuestion = questions[currentStep];

  const handleNext = () => {
    if (!responses[currentQuestion.key as keyof typeof responses].trim()) {
      toast.error("Por favor, compartilhe sua reflexão antes de continuar");
      return;
    }

    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleSubmit();
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const today = new Date();
      const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
      const weekNumber = Math.ceil((today.getTime() - new Date(today.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));

      const feedbackText = `
O que funcionou: ${responses.whatWorked}

O que não funcionou: ${responses.whatDidntWork}

Ajustes necessários: ${responses.adjustments}
      `.trim();

      const { error } = await supabase.from("feedback").insert({
        user_id: user.id,
        week_number: weekNumber,
        week_start_date: startOfWeek.toISOString().split('T')[0],
        feedback_text: feedbackText,
        feedback_type: "cycle_review",
      });

      if (error) throw error;

      toast.success("Revisão salva com sucesso!");
      navigate("/feedback");
    } catch (error) {
      console.error("Erro ao salvar revisão:", error);
      toast.error("Erro ao salvar revisão");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        title="Revisão do Ciclo" 
        subtitle="Momento de reflexão e aprendizado"
      />

      <main className="max-w-4xl mx-auto px-4 py-12">
        {/* Progress */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-4">
            {questions.map((_, index) => (
              <div
                key={index}
                className={`flex-1 h-2 rounded-full mx-1 transition-all ${
                  index <= currentStep
                    ? "bg-gradient-to-r from-primary to-secondary"
                    : "bg-muted"
                }`}
              />
            ))}
          </div>
          <p className="text-center text-muted-foreground font-body">
            Pergunta {currentStep + 1} de {questions.length}
          </p>
        </div>

        {/* Questão Atual */}
        <div className="bg-gradient-to-br from-card to-muted/30 rounded-[2.5rem] p-10 md:p-12 shadow-hover mb-8">
          <div className="mb-8">
            <div className="bg-gradient-to-r from-accent to-[hsl(var(--gold))] rounded-full w-16 h-16 flex items-center justify-center text-white text-2xl font-heading shadow-gold mb-6">
              {String(currentStep + 1).padStart(2, "0")}
            </div>
            <h2 className="text-3xl md:text-4xl font-heading text-foreground mb-3">
              {currentQuestion.title}
            </h2>
            <p className="text-muted-foreground text-lg font-body">
              {currentQuestion.subtitle}
            </p>
          </div>

          <Textarea
            value={responses[currentQuestion.key as keyof typeof responses]}
            onChange={(e) =>
              setResponses({
                ...responses,
                [currentQuestion.key]: e.target.value,
              })
            }
            placeholder={currentQuestion.placeholder}
            rows={8}
            className="text-lg resize-none mb-6"
          />

          <div className="flex gap-4">
            {currentStep > 0 && (
              <Button
                onClick={() => setCurrentStep(currentStep - 1)}
                variant="outline"
                size="lg"
                className="flex-1 text-lg py-6 rounded-full border-2"
              >
                Voltar
              </Button>
            )}
            <Button
              onClick={handleNext}
              disabled={loading}
              size="lg"
              className="flex-1 text-lg py-6 rounded-full shadow-tiffany"
            >
              {loading ? (
                "Salvando..."
              ) : currentStep < questions.length - 1 ? (
                <>
                  Próxima
                  <Send className="ml-2 h-5 w-5" />
                </>
              ) : (
                <>
                  Finalizar
                  <Send className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CycleReview;
