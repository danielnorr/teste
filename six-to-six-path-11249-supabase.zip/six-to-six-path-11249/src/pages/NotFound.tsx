import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import logo from "@/assets/logo.png";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background">
      <div className="text-center">
        <img src={logo} alt="binb norr" className="h-14 mx-auto mb-8" />
        <h1 className="mb-4 text-4xl font-heading font-bold">404</h1>
        <p className="mb-4 text-xl text-muted-foreground">Oops! Página não encontrada</p>
        <a href="/" className="text-primary underline hover:text-primary/80 font-body">
          Voltar para Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;
