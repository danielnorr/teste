import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Target, TrendingUp, CheckCircle2, Circle, LogOut } from "lucide-react";
import { GoalCard } from "@/components/dashboard/GoalCard";
import { WeeklyProgress } from "@/components/dashboard/WeeklyProgress";
import { toast } from "@/hooks/use-toast";
import { Header } from "@/components/common/Header";

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Logout realizado",
      description: "Até logo!",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-2xl font-heading">Carregando...</div>
      </div>
    );
  }

  // Mock data - será substituído por dados reais do Supabase
  const goals = [
    {
      id: "1",
      title: "Aumentar vendas em 30%",
      description: "Alcançar R$ 100k em vendas até o final do trimestre",
      progress: 65,
      timeframe: "6 semanas",
      status: "active",
    },
    {
      id: "2",
      title: "Lançar novo produto",
      description: "Desenvolver e lançar MVP da plataforma",
      progress: 40,
      timeframe: "6 meses",
      status: "active",
    },
    {
      id: "3",
      title: "Expandir equipe",
      description: "Contratar 5 novos desenvolvedores",
      progress: 80,
      timeframe: "6 semanas",
      status: "active",
    },
  ];

  const weeklyTasks = [
    { id: "1", title: "Revisar pipeline de vendas", completed: true },
    { id: "2", title: "Reunião com investidores", completed: true },
    { id: "3", title: "Finalizar protótipo", completed: false },
    { id: "4", title: "Entrevistar candidatos", completed: false },
    { id: "5", title: "Atualizar roadmap", completed: false },
  ];

  const weeklyScore = 68;

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-white to-[hsl(178,92%,95%)]">
      <Header 
        title="Dashboard" 
        subtitle={`Bem-vindo, ${user?.user_metadata?.name || user?.email}`}
      >
        <Button
          onClick={handleLogout}
          variant="outline"
          className="bg-white/10 border-white/30 text-white hover:bg-white hover:text-primary backdrop-blur-sm"
        >
          <LogOut className="h-5 w-5 mr-2" />
          Sair
        </Button>
      </Header>

      <main className="container mx-auto px-4 py-10">
        {/* Score Semanal */}
        <div className="mb-10">
          <div className="bg-card rounded-[2.5rem] shadow-hover p-10 md:p-12 hover-lift border-2 border-primary/20">
            <div className="flex items-start justify-between mb-8">
              <div className="flex-1">
                <h2 className="text-3xl md:text-4xl font-heading mb-3 text-foreground">
                  Score da Semana
                </h2>
                <p className="text-muted-foreground font-body text-lg mb-6">
                  Sua performance semanal baseada nas tarefas concluídas
                </p>
                <div className="flex items-baseline gap-3">
                  <span className="text-7xl md:text-8xl font-heading bg-gradient-tiffany bg-clip-text text-transparent">
                    {weeklyScore}
                  </span>
                  <span className="text-3xl text-muted-foreground">/100</span>
                </div>
              </div>
              <div className="bg-gradient-tiffany rounded-3xl p-6 shadow-tiffany">
                <TrendingUp className="h-16 w-16 md:h-20 md:w-20 text-white" strokeWidth={2.5} />
              </div>
            </div>
            
            {/* Tarefas da Semana */}
            <div className="mt-8 pt-8 border-t-2 border-border">
              <h3 className="text-xl font-heading mb-6 text-foreground">
                Tarefas desta semana ({weeklyTasks.filter(t => t.completed).length}/{weeklyTasks.length})
              </h3>
              <div className="space-y-3">
                {weeklyTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-4 bg-muted/50 rounded-2xl p-4 transition-bounce hover:bg-muted"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="h-6 w-6 flex-shrink-0 text-primary" strokeWidth={2.5} />
                    ) : (
                      <Circle className="h-6 w-6 flex-shrink-0 text-muted-foreground" strokeWidth={2.5} />
                    )}
                    <span
                      className={`font-body text-base text-foreground ${
                        task.completed
                          ? "line-through opacity-60"
                          : ""
                      }`}
                    >
                      {task.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Header de Metas */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="bg-gradient-tiffany rounded-2xl p-3 shadow-tiffany">
              <Target className="h-8 w-8 text-white" strokeWidth={2.5} />
            </div>
            <h2 className="text-3xl md:text-4xl font-heading text-foreground">Minhas Metas</h2>
          </div>
          <Button
            onClick={() => navigate("/nova-meta")}
            className="font-heading shadow-tiffany"
            size="lg"
          >
            <Plus className="h-5 w-5 mr-2" strokeWidth={2.5} />
            Nova Meta
          </Button>
        </div>

        {/* Grid de Metas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {goals.map((goal) => (
            <GoalCard key={goal.id} goal={goal} />
          ))}

          {/* Card de adicionar meta */}
          <button
            onClick={() => navigate("/nova-meta")}
            className="border-2 border-dashed border-border bg-muted/30 hover:bg-muted/60 hover:border-primary rounded-[2rem] transition-bounce p-10 flex flex-col items-center justify-center gap-6 min-h-[300px] hover-lift"
          >
            <div className="bg-gradient-to-r from-accent to-[hsl(var(--gold))] rounded-full p-4 shadow-gold">
              <Plus className="h-12 w-12 text-white" strokeWidth={2.5} />
            </div>
            <span className="text-xl font-heading text-foreground">
              Adicionar Nova Meta
            </span>
          </button>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
