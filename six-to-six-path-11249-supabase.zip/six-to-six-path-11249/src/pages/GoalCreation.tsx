import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Save } from "lucide-react";
import { toast } from "sonner";
import { Header } from "@/components/common/Header";

interface DraftGoal {
  id?: string;
  title: string;
  description: string;
  timeframe: "6_semanas" | "6_meses";
}

const GoalCreation = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [goals, setGoals] = useState<DraftGoal[]>([
    { title: "", description: "", timeframe: "6_semanas" },
  ]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
        loadDraftGoals(session.user.id);
      }
    });
  }, [navigate]);

  const loadDraftGoals = async (userId: string) => {
    const { data, error } = await supabase
      .from("draft_goals")
      .select("*")
      .eq("user_id", userId);

    if (!error && data && data.length > 0) {
      setGoals(data.map(g => ({
        id: g.id,
        title: g.title,
        description: g.description || "",
        timeframe: g.timeframe,
      })));
    }
  };

  const addGoal = () => {
    setGoals([...goals, { title: "", description: "", timeframe: "6_semanas" }]);
  };

  const removeGoal = (index: number) => {
    setGoals(goals.filter((_, i) => i !== index));
  };

  const updateGoal = (index: number, field: keyof DraftGoal, value: string) => {
    const newGoals = [...goals];
    newGoals[index] = { ...newGoals[index], [field]: value };
    setGoals(newGoals);
  };

  const saveGoals = async () => {
    setLoading(true);
    try {
      const validGoals = goals.filter(g => g.title.trim() !== "");
      
      if (validGoals.length === 0) {
        toast.error("Adicione pelo menos uma meta");
        setLoading(false);
        return;
      }

      // Calcula datas baseado no timeframe
      const goalsToInsert = validGoals.map(goal => {
        const startDate = new Date();
        const endDate = new Date();
        
        if (goal.timeframe === "6_semanas") {
          endDate.setDate(endDate.getDate() + 42); // 6 semanas
        } else {
          endDate.setMonth(endDate.getMonth() + 6); // 6 meses
        }

        return {
          user_id: user.id,
          title: goal.title,
          description: goal.description,
          timeframe: goal.timeframe,
          start_date: startDate.toISOString().split('T')[0],
          end_date: endDate.toISOString().split('T')[0],
          is_active: true,
        };
      });

      const { error } = await supabase.from("goals").insert(goalsToInsert);

      if (error) throw error;

      toast.success("Metas criadas com sucesso!");
      navigate("/dashboard");
    } catch (error) {
      console.error("Erro ao salvar metas:", error);
      toast.error("Erro ao salvar metas");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        title="Criar Metas" 
        subtitle="Defina suas metas e comece a trilhar seu caminho para o sucesso"
      />

      <main className="max-w-6xl mx-auto px-4 py-12">
        <div className="space-y-8">
          {goals.map((goal, index) => (
            <div
              key={index}
              className="bg-card rounded-[2.5rem] p-8 md:p-10 shadow-hover hover-lift border border-border"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="bg-gradient-to-r from-accent to-[hsl(var(--gold))] rounded-full w-16 h-16 flex items-center justify-center text-white text-2xl font-heading shadow-gold">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <h3 className="text-2xl font-heading text-foreground">
                    Meta {index + 1}
                  </h3>
                </div>
                {goals.length > 1 && (
                  <Button
                    onClick={() => removeGoal(index)}
                    variant="outline"
                    size="icon"
                    className="rounded-full border-destructive text-destructive hover:bg-destructive hover:text-white"
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                )}
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-heading text-foreground mb-2">
                    Título da Meta
                  </label>
                  <Input
                    value={goal.title}
                    onChange={(e) => updateGoal(index, "title", e.target.value)}
                    placeholder="Ex: Aumentar vendas em 30%"
                    className="text-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-heading text-foreground mb-2">
                    Descrição
                  </label>
                  <Textarea
                    value={goal.description}
                    onChange={(e) => updateGoal(index, "description", e.target.value)}
                    placeholder="Descreva sua meta em detalhes..."
                    rows={4}
                    className="text-base resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-heading text-foreground mb-3">
                    Prazo
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => updateGoal(index, "timeframe", "6_semanas")}
                      className={`p-4 rounded-2xl border-2 transition-bounce font-heading ${
                        goal.timeframe === "6_semanas"
                          ? "border-primary bg-primary/10 text-primary shadow-tiffany"
                          : "border-border bg-muted text-foreground hover:border-primary/50"
                      }`}
                    >
                      6 Semanas
                    </button>
                    <button
                      onClick={() => updateGoal(index, "timeframe", "6_meses")}
                      className={`p-4 rounded-2xl border-2 transition-bounce font-heading ${
                        goal.timeframe === "6_meses"
                          ? "border-primary bg-primary/10 text-primary shadow-tiffany"
                          : "border-border bg-muted text-foreground hover:border-primary/50"
                      }`}
                    >
                      6 Meses
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Botões de Ação */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={addGoal}
              variant="outline"
              size="lg"
              className="flex-1 text-lg py-6 rounded-full border-2 hover:bg-accent/10 hover:border-accent"
            >
              <Plus className="h-5 w-5 mr-2" />
              Adicionar Mais uma Meta
            </Button>

            <Button
              onClick={saveGoals}
              disabled={loading}
              size="lg"
              className="flex-1 text-lg py-6 rounded-full shadow-tiffany"
            >
              <Save className="h-5 w-5 mr-2" />
              {loading ? "Salvando..." : "Salvar e Começar"}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default GoalCreation;
