import { Button } from "@/components/ui/button";
import { ArrowRight, Target, Zap, TrendingUp, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Logo no topo */}
      <div className="container mx-auto px-4 pt-8">
        <img src={logo} alt="binb norr" className="h-12 md:h-14" />
      </div>

      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-12 pb-32 text-center animate-fade-in">
        <div className="max-w-5xl mx-auto space-y-10">
          <div className="inline-block px-8 py-4 bg-gradient-tiffany text-white rounded-full shadow-tiffany font-heading text-sm mb-6 animate-scale-in hover-lift">
            🎯 Transforme sua vida em até 6 meses
          </div>
          
          <h1 className="text-6xl md:text-8xl font-heading tracking-tight animate-slide-up leading-tight">
            Alcance seus objetivos em
            <span className="block bg-gradient-to-r from-primary via-secondary to-[hsl(var(--tiffany-light))] bg-clip-text text-transparent mt-4">
              6 meses ou menos
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-foreground max-w-3xl mx-auto animate-slide-up font-body leading-relaxed" style={{ animationDelay: '0.1s' }}>
            Com a metodologia 6in6, você reduz até 6 semanas do tempo necessário para conquistar suas metas através de um sistema inteligente guiado por IA.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <Link to="/auth">
              <Button variant="default" size="lg" className="text-lg px-10 shadow-tiffany">
                Começar agora
                <ArrowRight className="ml-2 h-6 w-6" />
              </Button>
            </Link>
            <Link to="/dashboard">
              <Button variant="secondary" size="lg" className="text-lg px-10 shadow-blue">
                Ver demonstração
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-24 bg-gradient-to-b from-background to-muted/30">
        <div className="text-center mb-20 animate-fade-in">
          <h2 className="text-4xl md:text-6xl font-heading mb-6 leading-tight">
            Como funciona o 6in6
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-body leading-relaxed">
            Um sistema completo que te acompanha do primeiro dia até a conquista dos seus objetivos
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <FeatureCard
            icon={<Target className="h-10 w-10" />}
            title="Discovery com IA"
            description="Nossa IA conversacional te ajuda a descobrir o que você realmente quer alcançar, identificando antimetas e objetivos verdadeiros."
            number="01"
            gradient="from-primary to-secondary"
          />
          
          <FeatureCard
            icon={<Zap className="h-10 w-10" />}
            title="Metas SMART"
            description="Transformamos suas aspirações em metas específicas, mensuráveis, atingíveis, relevantes e com prazo definido."
            number="02"
            gradient="from-secondary to-[hsl(var(--tiffany-light))]"
          />
          
          <FeatureCard
            icon={<TrendingUp className="h-10 w-10" />}
            title="Execução & Score"
            description="Acompanhe seu progresso semanal, receba feedback inteligente e ajustes personalizados para garantir o sucesso."
            number="03"
            gradient="from-accent to-[hsl(var(--gold))]"
          />
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container mx-auto px-4 py-24">
        <div className="bg-card rounded-[3rem] shadow-soft-lg p-12 md:p-16 max-w-6xl mx-auto card-tilt border border-border">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl font-heading leading-tight text-foreground">
                Por que escolher o 6in6?
              </h2>
              <div className="space-y-5">
                <BenefitItem text="Sistema validado de definição e acompanhamento de metas" />
                <BenefitItem text="IA que entende suas necessidades e contexto único" />
                <BenefitItem text="Follow-ups automáticos e feedback personalizado" />
                <BenefitItem text="Metodologia que reduz o tempo de conquista em até 6 semanas" />
                <BenefitItem text="Interface intuitiva e fácil de usar" />
              </div>
              <Link to="/auth">
                <Button variant="default" size="lg" className="mt-6 shadow-orange">
                  Comece sua jornada
                  <ArrowRight className="ml-2" />
                </Button>
              </Link>
            </div>
            
            <div className="bg-gradient-to-br from-muted to-background rounded-[2.5rem] p-10 space-y-8 shadow-soft border border-border">
              <div className="text-center pb-8 border-b-2 border-border">
                <div className="text-7xl font-heading bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-3">6</div>
                <div className="text-lg text-foreground font-body">meses para resultados</div>
              </div>
              <div className="text-center pb-8 border-b-2 border-border">
                <div className="text-7xl font-heading bg-gradient-to-r from-secondary to-[hsl(var(--tiffany-light))] bg-clip-text text-transparent mb-3">6</div>
                <div className="text-lg text-foreground font-body">semanas economizadas</div>
              </div>
              <div className="text-center">
                <div className="text-7xl font-heading bg-gradient-to-r from-accent to-[hsl(var(--gold))] bg-clip-text text-transparent mb-3">100%</div>
                <div className="text-lg text-foreground font-body">focado em você</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-24 text-center">
        <div className="max-w-4xl mx-auto space-y-8 bg-gradient-tiffany text-white rounded-[3rem] shadow-hover p-16 hover-lift">
          <h2 className="text-5xl md:text-6xl font-heading leading-tight">
            Pronto para começar sua transformação?
          </h2>
          <p className="text-xl md:text-2xl font-body opacity-90 max-w-2xl mx-auto">
            Junte-se a milhares de pessoas que já estão conquistando seus objetivos com o 6in6
          </p>
          <Link to="/auth">
            <Button variant="default" size="lg" className="text-lg px-14 py-7 h-auto shadow-orange bg-white text-primary hover:scale-110 hover:bg-white">
              Criar conta gratuita
              <ArrowRight className="ml-3 h-6 w-6" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ 
  icon, 
  title, 
  description,
  number,
  gradient
}: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
  number: string;
  gradient: string;
}) => {
  return (
    <div className="relative bg-card rounded-[2.5rem] shadow-soft hover-lift p-10 space-y-6 group overflow-hidden border border-border">
      <div className="absolute top-6 right-6 text-8xl font-heading opacity-5 text-foreground">{number}</div>
      <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${gradient} flex items-center justify-center text-white shadow-soft transition-bounce group-hover:scale-110 group-hover:rotate-3`}>
        {icon}
      </div>
      <h3 className="text-2xl md:text-3xl font-heading leading-tight text-foreground">{title}</h3>
      <p className="text-muted-foreground leading-relaxed font-body text-base">{description}</p>
    </div>
  );
};

const BenefitItem = ({ text }: { text: string }) => {
  return (
    <div className="flex items-start gap-3">
      <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" strokeWidth={3} />
      <span className="text-foreground font-body">{text}</span>
    </div>
  );
};

export default Index;
