import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send } from "lucide-react";
import { Message } from "@/components/chat/Message";
import { TypingIndicator } from "@/components/chat/TypingIndicator";
import { toast } from "sonner";
import { Header } from "@/components/common/Header";

interface ChatMessage {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
}

const Chat = () => {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const sendMessage = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    try {
      const response = await fetch("https://n8n.norr.com.br/webhook/discovery", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: input }),
      });

      if (!response.ok) {
        throw new Error("Falha ao enviar mensagem");
      }

      // Verifica se é conclusão do discovery (201) ou mensagem normal (200)
      if (response.status === 201) {
        // Discovery concluído - salva dados e redireciona
        const responseText = await response.text();
        console.log("Discovery concluído:", responseText);
        
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          content: responseText || "Discovery concluído!",
          role: "assistant",
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, assistantMessage]);
        
        // Salva o discovery no banco
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { error: dbError } = await supabase.from('user_discovery').upsert([
            {
              user_id: user.id,
              completed: true,
              chat_history: messages.concat(assistantMessage) as any,
              updated_at: new Date().toISOString(),
            }
          ]);
          
          if (dbError) console.error("Erro ao salvar discovery:", dbError);
        }

        // Aguarda 2 segundos para mostrar a mensagem final antes de redirecionar
        setTimeout(() => {
          navigate("/goal-creation");
        }, 2000);
      } else {
        // Mensagem normal (200)
        const responseText = await response.text();
        console.log("Resposta do webhook:", responseText);
        
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          content: responseText || "Sem resposta",
          role: "assistant",
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, assistantMessage]);
      }
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      toast.error("Erro ao enviar mensagem. Tente novamente.");
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header 
        title="Discovery Chat" 
        subtitle="Converse e descubra novas possibilidades"
      />

      {/* Messages Container with generous spacing */}
      <div className="flex-1 overflow-y-auto p-8 md:p-12 space-y-8 max-w-6xl mx-auto w-full">
        {messages.length === 0 && (
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="text-center space-y-6 p-12 rounded-3xl bg-gradient-to-br from-muted to-background shadow-soft-lg hover-lift">
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-tiffany flex items-center justify-center shadow-tiffany">
                <Send className="h-10 w-10 text-white" />
              </div>
              <p className="text-3xl md:text-4xl font-heading font-bold uppercase text-foreground">
                Comece a conversa
              </p>
              <p className="text-muted-foreground font-body text-lg max-w-md">
                Digite uma mensagem para descobrir algo novo e interessante
              </p>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <Message key={message.id} message={message} />
        ))}

        {isTyping && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area with floating design */}
      <div className="sticky bottom-0 bg-background/80 backdrop-blur-lg border-t border-border p-6 md:p-8 shadow-soft-lg">
        <div className="flex gap-3 max-w-5xl mx-auto">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Digite sua mensagem..."
            disabled={isTyping}
            className="flex-1 text-lg"
          />
          <Button
            onClick={sendMessage}
            disabled={!input.trim() || isTyping}
            size="icon"
            className="shrink-0"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
