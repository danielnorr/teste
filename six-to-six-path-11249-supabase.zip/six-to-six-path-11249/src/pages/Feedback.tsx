import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Trophy, TrendingUp, Target, ArrowRight, Sparkles } from "lucide-react";
import { Header } from "@/components/common/Header";

const Feedback = () => {
  const navigate = useNavigate();
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLastScore();
  }, []);

  const loadLastScore = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("weekly_score")
      .select("score")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (data) {
      setScore(Number(data.score));
    }
    setLoading(false);
  };

  const getFeedback = () => {
    if (score >= 90) {
      return {
        title: "Performance Excepcional! 🎉",
        message: "Você está no topo do seu jogo! Sua dedicação e consistência são inspiradoras. Continue assim e você alcançará resultados extraordinários.",
        tips: [
          "Mantenha suas rotinas que estão funcionando",
          "Considere aumentar o desafio das suas metas",
          "Compartilhe suas estratégias com a equipe",
        ],
        gradient: "from-green-500 via-emerald-600 to-teal-600",
        icon: Trophy,
      };
    } else if (score >= 80) {
      return {
        title: "Ótimo Trabalho! 💪",
        message: "Você está muito perto da excelência! Com alguns ajustes estratégicos, você pode alcançar o nível máximo de performance.",
        tips: [
          "Identifique o que impediu os últimos 10-20%",
          "Refine suas prioridades para focar no essencial",
          "Elimine distrações e bloqueie tempo para deep work",
        ],
        gradient: "from-blue-500 via-cyan-600 to-sky-600",
        icon: TrendingUp,
      };
    } else {
      return {
        title: "Hora de Ajustar a Rota 🎯",
        message: "Todo processo de crescimento tem seus desafios. Vamos identificar o que pode ser melhorado e criar estratégias mais eficazes para a próxima semana.",
        tips: [
          "Revise suas metas - elas estão realistas?",
          "Divida tarefas grandes em partes menores",
          "Identifique e elimine bloqueadores",
          "Peça ajuda quando necessário",
        ],
        gradient: "from-orange-500 via-amber-600 to-yellow-600",
        icon: Target,
      };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-2xl font-heading">Carregando...</div>
      </div>
    );
  }

  const feedback = getFeedback();
  const Icon = feedback.icon;

  return (
    <div className="min-h-screen bg-background">
      <Header 
        title={feedback.title} 
        subtitle={`Score: ${score} pontos`}
      />

      <main className="max-w-4xl mx-auto px-4 py-12 space-y-8">
        {/* Mensagem Principal */}
        <div className="bg-gradient-to-br from-card to-muted/30 rounded-[2.5rem] p-10 md:p-12 shadow-hover">
          <div className="flex items-start gap-6">
            <div className={`bg-gradient-to-r ${feedback.gradient} rounded-2xl p-4 shadow-soft`}>
              <Sparkles className="h-8 w-8 text-white" strokeWidth={2.5} />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-heading mb-4 text-foreground">
                Análise da Semana
              </h2>
              <p className="text-muted-foreground font-body leading-relaxed text-lg">
                {feedback.message}
              </p>
            </div>
          </div>
        </div>

        {/* Dicas e Recomendações */}
        <div className="bg-gradient-to-br from-card to-muted/30 rounded-[2.5rem] p-10 md:p-12 shadow-hover">
          <h3 className="text-2xl font-heading mb-6 text-foreground flex items-center gap-3">
            <div className={`bg-gradient-to-r ${feedback.gradient} rounded-xl p-2 shadow-soft`}>
              <Target className="h-6 w-6 text-white" strokeWidth={2.5} />
            </div>
            Recomendações para a Próxima Semana
          </h3>
          <ul className="space-y-4">
            {feedback.tips.map((tip, index) => (
              <li
                key={index}
                className="flex items-start gap-4 p-4 bg-background/60 rounded-2xl transition-bounce hover:bg-background"
              >
                <div className={`bg-gradient-to-r ${feedback.gradient} rounded-full w-8 h-8 flex items-center justify-center text-white text-sm font-heading shadow-soft flex-shrink-0`}>
                  {index + 1}
                </div>
                <span className="text-foreground font-body text-lg pt-1">
                  {tip}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Botão para Dashboard */}
        <Button
          onClick={() => navigate("/dashboard")}
          size="lg"
          className="w-full text-xl py-8 rounded-full shadow-tiffany font-heading"
        >
          Voltar ao Dashboard
          <ArrowRight className="ml-3 h-6 w-6" strokeWidth={2.5} />
        </Button>
      </main>
    </div>
  );
};

export default Feedback;
