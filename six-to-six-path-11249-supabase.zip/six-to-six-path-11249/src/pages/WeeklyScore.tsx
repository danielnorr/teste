import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { TrendingUp, Award, ArrowRight } from "lucide-react";
import { Header } from "@/components/common/Header";

const WeeklyScore = () => {
  const navigate = useNavigate();
  const [score, setScore] = useState(0);
  const [weekNumber, setWeekNumber] = useState(1);
  const [completedTasks, setCompletedTasks] = useState(0);
  const [totalTasks, setTotalTasks] = useState(0);

  useEffect(() => {
    loadWeeklyScore();
  }, []);

  const loadWeeklyScore = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Busca o score da semana atual
    const today = new Date();
    const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
    
    const { data } = await supabase
      .from("weekly_score")
      .select("*")
      .eq("user_id", user.id)
      .eq("week_start_date", startOfWeek.toISOString().split('T')[0])
      .single();

    if (data) {
      setScore(Number(data.score));
      setWeekNumber(data.week_number);
      setCompletedTasks(data.completed_tasks);
      setTotalTasks(data.total_tasks);
    }
  };

  const getPerformanceLevel = () => {
    if (score >= 90) return { level: "Excelente", color: "from-green-500 to-emerald-600" };
    if (score >= 80) return { level: "Muito Bom", color: "from-blue-500 to-cyan-600" };
    return { level: "Em Progresso", color: "from-orange-500 to-amber-600" };
  };

  const performance = getPerformanceLevel();

  return (
    <div className="min-h-screen bg-background">
      <Header 
        title="Score Semanal" 
        subtitle={`Semana ${weekNumber} - Resumo da sua performance`}
      />

      <main className="max-w-4xl mx-auto px-4 py-12 space-y-8">
        {/* Card Principal de Score */}
        <div className={`bg-gradient-to-br ${performance.color} text-white rounded-[2.5rem] p-12 md:p-16 shadow-hover hover-lift text-center`}>
          <div className="mb-8">
            <div className="bg-white/20 backdrop-blur-sm rounded-full w-24 h-24 mx-auto flex items-center justify-center mb-6 shadow-soft">
              <Award className="h-14 w-14" strokeWidth={2.5} />
            </div>
            <h2 className="text-2xl font-heading mb-4 opacity-90">
              {performance.level}
            </h2>
          </div>
          
          <div className="mb-8">
            <div className="text-9xl md:text-[12rem] font-heading leading-none mb-4">
              {score}
            </div>
            <div className="text-3xl opacity-80 font-body">
              pontos
            </div>
          </div>

          <div className="flex items-center justify-center gap-8 text-lg font-body">
            <div>
              <div className="text-4xl font-heading">{completedTasks}</div>
              <div className="opacity-80">Tarefas Concluídas</div>
            </div>
            <div className="text-6xl opacity-40">/</div>
            <div>
              <div className="text-4xl font-heading">{totalTasks}</div>
              <div className="opacity-80">Total de Tarefas</div>
            </div>
          </div>
        </div>

        {/* Mensagem Motivacional */}
        <div className="bg-gradient-to-br from-card to-muted/30 rounded-[2.5rem] p-10 shadow-hover">
          <div className="flex items-start gap-6">
            <div className="bg-gradient-to-r from-accent to-[hsl(var(--gold))] rounded-2xl p-4 shadow-gold">
              <TrendingUp className="h-8 w-8 text-white" strokeWidth={2.5} />
            </div>
            <div className="flex-1">
              <h3 className="text-2xl font-heading mb-3 text-foreground">
                {score >= 90 ? "Incrível!" : score >= 80 ? "Ótimo trabalho!" : "Continue firme!"}
              </h3>
              <p className="text-muted-foreground font-body leading-relaxed text-lg">
                {score >= 90 
                  ? "Você está arrasando! Continue mantendo esse ritmo excepcional."
                  : score >= 80
                  ? "Você está no caminho certo. Só mais um pouquinho para chegar na excelência!"
                  : "Toda jornada tem seus desafios. Vamos revisar suas estratégias e ajustar o que for necessário."}
              </p>
            </div>
          </div>
        </div>

        {/* Botão para próxima etapa */}
        <Button
          onClick={() => navigate("/cycle-review")}
          size="lg"
          className="w-full text-xl py-8 rounded-full shadow-tiffany font-heading"
        >
          Fazer Revisão do Ciclo
          <ArrowRight className="ml-3 h-6 w-6" strokeWidth={2.5} />
        </Button>
      </main>
    </div>
  );
};

export default WeeklyScore;
