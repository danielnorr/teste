import { ReactNode } from "react";
import logo from "@/assets/logo.png";

interface HeaderProps {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}

export const Header = ({ title, subtitle, children }: HeaderProps) => {
  return (
    <header className="relative bg-gradient-to-r from-primary via-secondary to-[hsl(var(--tiffany-light))] shadow-soft-lg overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
      </div>
      <div className="container mx-auto px-4 py-8 relative">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <img src={logo} alt="binb norr" className="h-14 md:h-16" />
            <div>
              <h1 className="text-4xl md:text-5xl font-heading text-white mb-2">{title}</h1>
              {subtitle && (
                <p className="text-white/80 font-body text-lg">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          {children}
        </div>
      </div>
    </header>
  );
};
