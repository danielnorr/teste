interface MessageProps {
  message: {
    content: string;
    role: "user" | "assistant";
    timestamp: Date;
  };
}

export const Message = ({ message }: MessageProps) => {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} animate-fade-in`}>
      <div
        className={`max-w-[75%] md:max-w-[60%] p-6 md:p-8 rounded-3xl transition-bounce hover-lift ${
          isUser
            ? "bg-gradient-tiffany text-white shadow-tiffany"
            : "bg-gradient-to-br from-secondary to-accent text-white shadow-coral"
        }`}
      >
        <p className="font-body text-base md:text-lg whitespace-pre-wrap break-words leading-relaxed">
          {message.content}
        </p>
        <span className="text-xs md:text-sm opacity-80 mt-3 block font-body">
          {message.timestamp.toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </span>
      </div>
    </div>
  );
};
