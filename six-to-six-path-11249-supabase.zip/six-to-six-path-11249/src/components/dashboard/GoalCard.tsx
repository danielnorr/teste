import { Target, TrendingUp, Clock } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface Goal {
  id: string;
  title: string;
  description: string;
  progress: number;
  timeframe: string;
  status: string;
}

interface GoalCardProps {
  goal: Goal;
}

export const GoalCard = ({ goal }: GoalCardProps) => {
  const getGradient = (progress: number) => {
    if (progress >= 70) return "from-accent to-[hsl(var(--gold))]";
    if (progress >= 40) return "from-primary to-secondary";
    return "from-[hsl(var(--coral))] to-primary";
  };

  return (
    <div className="bg-card rounded-[2.5rem] shadow-soft hover-lift p-8 cursor-pointer transition-bounce card-tilt border border-border">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div className={`bg-gradient-to-br ${getGradient(goal.progress)} rounded-2xl p-3 shadow-soft`}>
          <Target className="h-7 w-7 text-white" strokeWidth={2.5} />
        </div>
        <span className="text-xs font-heading bg-muted text-foreground px-4 py-2 rounded-full border border-border">
          {goal.timeframe}
        </span>
      </div>

      {/* Título */}
      <h3 className="text-2xl font-heading text-foreground mb-3 line-clamp-2 leading-tight">
        {goal.title}
      </h3>

      {/* Descrição */}
      <p className="text-base font-body text-muted-foreground mb-6 line-clamp-2 leading-relaxed">
        {goal.description}
      </p>

      {/* Progresso */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-heading text-foreground">Progresso</span>
          <span className={`text-xl font-heading bg-gradient-to-r ${getGradient(goal.progress)} bg-clip-text text-transparent`}>
            {goal.progress}%
          </span>
        </div>
        
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div
            className={`h-full bg-gradient-to-r ${getGradient(goal.progress)} transition-all duration-700 ease-out rounded-full`}
            style={{ width: `${goal.progress}%` }}
          />
        </div>
      </div>

      {/* Footer */}
      <div className="mt-6 pt-6 border-t border-border flex items-center justify-between">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Clock className="h-4 w-4" strokeWidth={2.5} />
          <span className="text-xs font-body">Atualizado hoje</span>
        </div>
        <div className="bg-gradient-to-r from-accent to-[hsl(var(--gold))] rounded-full p-2">
          <TrendingUp className="h-4 w-4 text-white" strokeWidth={2.5} />
        </div>
      </div>
    </div>
  );
};
