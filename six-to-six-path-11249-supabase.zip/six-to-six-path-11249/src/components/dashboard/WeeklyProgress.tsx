import { CheckCircle2, Circle } from "lucide-react";

interface Task {
  id: string;
  title: string;
  completed: boolean;
}

interface WeeklyProgressProps {
  tasks: Task[];
  score: number;
}

export const WeeklyProgress = ({ tasks, score }: WeeklyProgressProps) => {
  const completedTasks = tasks.filter((t) => t.completed).length;

  return (
    <div className="border-4 border-foreground bg-card shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-2xl font-heading text-foreground mb-1">
            Progresso Semanal
          </h3>
          <p className="text-sm font-body text-muted-foreground">
            {completedTasks} de {tasks.length} tarefas concluídas
          </p>
        </div>
        <div className="text-right">
          <div className="text-4xl font-heading text-primary">{score}</div>
          <div className="text-sm font-body text-muted-foreground">pontos</div>
        </div>
      </div>

      <div className="space-y-3">
        {tasks.map((task) => (
          <div
            key={task.id}
            className={`border-2 border-foreground p-3 flex items-center gap-3 transition-all ${
              task.completed
                ? "bg-accent/20"
                : "bg-muted/50"
            }`}
          >
            {task.completed ? (
              <CheckCircle2 className="h-5 w-5 text-accent" strokeWidth={3} />
            ) : (
              <Circle className="h-5 w-5 text-muted-foreground" strokeWidth={3} />
            )}
            <span
              className={`font-body ${
                task.completed
                  ? "text-foreground line-through"
                  : "text-foreground"
              }`}
            >
              {task.title}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
