-- Corrigir função update_updated_at_column para ter search_path
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Adicionar políticas RLS para a tabela organizations
-- Permitir que usuários vejam organizações
CREATE POLICY "Usuários podem ver organizações através de seus perfis"
ON public.organizations
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.organization_id = organizations.id
    AND profiles.id = auth.uid()
  )
);

-- Permitir que administradores gerenciem organizações
CREATE POLICY "Administradores podem gerenciar organizações"
ON public.organizations
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.organization_id = organizations.id
    AND profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.organization_id = organizations.id
    AND profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);