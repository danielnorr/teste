
-- Migration: 20251101203725
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tipo enum para papéis de usuário
CREATE TYPE user_role AS ENUM ('user', 'admin', 'mentor', 'coach');

-- Tipo enum para timeframes
CREATE TYPE goal_timeframe AS ENUM ('6_semanas', '6_meses');

-- Tabela de organizações (multi-tenant)
CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;

-- Tabela de perfis de usuário (extende auth.users)
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id uuid REFERENCES organizations(id) ON DELETE CASCADE,
  name text,
  avatar_url text,
  role user_role DEFAULT 'user',
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Tabela de discovery/onboarding
CREATE TABLE user_discovery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  areas_de_vida text[] DEFAULT '{}',
  nao_quero_mais text,
  visao_6_meses text,
  visao_6_semanas text,
  chat_history jsonb DEFAULT '[]',
  completed boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE user_discovery ENABLE ROW LEVEL SECURITY;

-- Tabela de metas em rascunho (sugeridas pela IA)
CREATE TABLE draft_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  why text,
  timeframe goal_timeframe NOT NULL,
  is_smart_ready boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE draft_goals ENABLE ROW LEVEL SECURITY;

-- Tabela de metas confirmadas
CREATE TABLE goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  timeframe goal_timeframe NOT NULL,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

-- Tabela de tarefas semanais
CREATE TABLE weekly_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id uuid REFERENCES goals(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  week_number int NOT NULL,
  week_start_date date NOT NULL,
  completed boolean DEFAULT false,
  completed_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE weekly_tasks ENABLE ROW LEVEL SECURITY;

-- Tabela de log de tarefas (histórico de conclusão)
CREATE TABLE task_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES weekly_tasks(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  completed_at timestamp with time zone DEFAULT now(),
  notes text
);

-- Habilitar RLS
ALTER TABLE task_log ENABLE ROW LEVEL SECURITY;

-- Tabela de scores semanais
CREATE TABLE weekly_score (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  week_number int NOT NULL,
  week_start_date date NOT NULL,
  score decimal(5,2) NOT NULL CHECK (score >= 0 AND score <= 100),
  total_tasks int NOT NULL DEFAULT 0,
  completed_tasks int NOT NULL DEFAULT 0,
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, week_number, week_start_date)
);

-- Habilitar RLS
ALTER TABLE weekly_score ENABLE ROW LEVEL SECURITY;

-- Tabela de feedback da IA
CREATE TABLE feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  week_number int NOT NULL,
  week_start_date date NOT NULL,
  feedback_text text NOT NULL,
  feedback_type text, -- 'encouragement', 'adjustment', 'warning'
  created_at timestamp with time zone DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;

-- Políticas de RLS para profiles
CREATE POLICY "Usuários podem ver seu próprio perfil"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Usuários podem atualizar seu próprio perfil"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Políticas de RLS para user_discovery
CREATE POLICY "Usuários podem ver seu próprio discovery"
  ON user_discovery FOR ALL
  USING (auth.uid() = user_id);

-- Políticas de RLS para draft_goals
CREATE POLICY "Usuários podem gerenciar suas metas em rascunho"
  ON draft_goals FOR ALL
  USING (auth.uid() = user_id);

-- Políticas de RLS para goals
CREATE POLICY "Usuários podem gerenciar suas metas"
  ON goals FOR ALL
  USING (auth.uid() = user_id);

-- Políticas de RLS para weekly_tasks
CREATE POLICY "Usuários podem ver tarefas de suas metas"
  ON weekly_tasks FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM goals
    WHERE goals.id = weekly_tasks.goal_id
    AND goals.user_id = auth.uid()
  ));

CREATE POLICY "Usuários podem atualizar tarefas de suas metas"
  ON weekly_tasks FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM goals
    WHERE goals.id = weekly_tasks.goal_id
    AND goals.user_id = auth.uid()
  ));

-- Políticas de RLS para task_log
CREATE POLICY "Usuários podem gerenciar seus logs de tarefas"
  ON task_log FOR ALL
  USING (auth.uid() = user_id);

-- Políticas de RLS para weekly_score
CREATE POLICY "Usuários podem ver seus próprios scores"
  ON weekly_score FOR ALL
  USING (auth.uid() = user_id);

-- Políticas de RLS para feedback
CREATE POLICY "Usuários podem ver seus próprios feedbacks"
  ON feedback FOR ALL
  USING (auth.uid() = user_id);

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_discovery_updated_at BEFORE UPDATE ON user_discovery
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_draft_goals_updated_at BEFORE UPDATE ON draft_goals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_goals_updated_at BEFORE UPDATE ON goals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_weekly_tasks_updated_at BEFORE UPDATE ON weekly_tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Função para criar perfil automaticamente quando usuário se registra
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.email)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger para criar perfil automaticamente
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Índices para performance
CREATE INDEX idx_profiles_organization_id ON profiles(organization_id);
CREATE INDEX idx_user_discovery_user_id ON user_discovery(user_id);
CREATE INDEX idx_draft_goals_user_id ON draft_goals(user_id);
CREATE INDEX idx_goals_user_id ON goals(user_id);
CREATE INDEX idx_goals_active ON goals(is_active);
CREATE INDEX idx_weekly_tasks_goal_id ON weekly_tasks(goal_id);
CREATE INDEX idx_weekly_tasks_week ON weekly_tasks(week_number);
CREATE INDEX idx_task_log_user_id ON task_log(user_id);
CREATE INDEX idx_weekly_score_user_week ON weekly_score(user_id, week_number);
CREATE INDEX idx_feedback_user_week ON feedback(user_id, week_number);

